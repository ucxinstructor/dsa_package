TODO
====

- Allow NetworkX access to draw class
- Capture and verify output of tree structures
- Clean up type hints across the package