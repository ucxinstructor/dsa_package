'''
dsa package for UC Berkeley Extension's Computer Science X404.1 Data Structures and Algorithms class

Last Revision: 6/14/2025
'''
version = '2025.6.14'
__version__ = '2025.6.14'
