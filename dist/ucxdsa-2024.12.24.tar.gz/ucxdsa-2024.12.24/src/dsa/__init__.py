'''
dsa package for UC Berkeley Extension's Computer Science X404.1 Data Structures and Algorithms class

Last Revision: 12/24/2024
'''
version = '2024.12.24'
__version__ = '2024.12.24'
