* Put comparison overloading to all data structures
* Implement Hash Set
* Hashtable: add enumeration
* Add more options for random Graph generation
* Clean up documentation
* Clean up test cases
