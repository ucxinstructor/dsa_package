* separate the Dijkstra code from graph
* add topsort
* add prim's?
* use only DSA classes
* add more type hints
