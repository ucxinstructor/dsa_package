'''
dsa package for UC Berkeley Extension's Computer Science X404.1 Data Structures and Algorithms class
Last Revision: 5/9/2024
'''
version = '2024.5.9'
